public class EmpCard {
    
    public static void createCard(String name) {
        System.out.println("Created card for " + name);
    }
}
